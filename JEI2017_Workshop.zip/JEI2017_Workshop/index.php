<!DOCTYPE html>
<html lang="pt">
<head>
	<?php include('head.php'); ?>
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
</head>
<body>
	<div id='pagina'>
		<div id='cabecalho'>
			<?php include('cabecalho.php'); ?>
		</div>		
		<div id='menu'>
			<?php include('menu.php'); ?>
		</div>	
		<div id='conteudo'>
			<h1>Coloque aqui o conteúdo<h1>
			<p></p>
		</div>
		<div id='rodape'>	
			<?php include('rodape.php'); ?>
		</div>		
	</div>	
</body>
</html>






