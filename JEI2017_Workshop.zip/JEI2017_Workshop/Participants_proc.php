<?php
    session_start();
	  require_once('InputValidation/CBaseFormValidation.php');
?>
<!DOCTYPE html>
<html lang="pt">
<head>
	<?php include('head.php'); ?>
  <link rel="stylesheet" type="text/css" href="css/estilos.css">
		<link rel="stylesheet" type="text/css" href="css/estilos_lista.css">
</head>
<body>
	<div id='pagina'>
		<div id='cabecalho'>
			<?php include('cabecalho.php'); ?>
		</div>		
		<div id='menu'>
			<?php include('menu.php'); ?>
		</div>	
		<div id='conteudo'>
<?php

    $nomeCompleto = CBaseFormValidation::test_input($_POST['NomeCompleto']);
    $curso = CBaseFormValidation::test_input($_POST['Curso']);
    $escola = CBaseFormValidation::test_input($_POST['Escola']);
    $email = CBaseFormValidation::test_input($_POST['Email']);
    $emailRetype = CBaseFormValidation::test_input($_POST['EmailRetype']);
    $telemovel = CBaseFormValidation::test_input($_POST['Telemovel']);
    $ano = CBaseFormValidation::test_input($_POST['Ano']);
    $nivel = "0"; 
    $numberOfVisits = 0;
    $data_cancelamento = '';
    $data = date("Y/m/d G:i:s", time());  
    $referenciaConfirmacao = sha1($data . $email);
    $data_inscricao = $data;
    $situacaoInscricao = 'NAO CONFIRMADA';

    // validação de dados
    $ERR = 0;
    $V = array();
    if (1==1) {

    }

    /* base de dados - ligação */
    //require_once('/var/../db.php');

		$dbName =  'jei2017_php_mysql'; 
    $dbPass = '';
    $dbUser = 'root';
    $dbHost = 'localhost';
    $dbPort = '3306';
		$dbTableName = 'participantes';
	
		try {
        $options = array(1002 => 'SET NAMES UTF8');
        $ligacao = new PDO("mysql:host={$dbHost}; dbname={$dbName}; port={$dbPort}", $dbUser, $dbPass, $options);
				$ligacao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $pe) {
        echo($pe->getMessage());
    }
		// Criar base de dados	
		$sql = "CREATE database IF NOT EXISTS $dbName";
		$stmt = $ligacao->prepare($sql);
    $stmt->execute();
				
				
	  $sql = "CREATE TABLE IF NOT EXISTS $dbTableName  (
        ID int(6) NOT NULL AUTO_INCREMENT,
        SUBMIT_DATE timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        NomeCompleto varchar(60)  NOT NULL,
        Curso varchar(100) NOT NULL,
        Escola varchar(60) NOT NULL,
        Email varchar(40)  NOT NULL,
        EmailRetype varchar(40)  NOT NULL,
        Telemovel varchar(12)  NOT NULL,
        Ano varchar(20)  NOT NULL,

        Nivel varchar(10)  NOT NULL DEFAULT '0',
        NumberOfVisits int(11) DEFAULT '0',
        SituacaoInscricao varchar(30)  NOT NULL DEFAULT 'NAO CONFIRMADA',
        ReferenciaConfirmacao varchar(100)  NOT NULL,
        data_inscricao datetime DEFAULT NULL,
        data_confirmacao datetime DEFAULT NULL,
        data_cancelamento datetime DEFAULT NULL,
        Data datetime DEFAULT NULL,
        PRIMARY KEY (ID)
    );";
    $stmt = $ligacao->prepare($sql);
    $stmt->execute();
			
		$res = null;
		try {
        $sql = "INSERT INTO $dbTableName  (NomeCompleto, Curso, Escola, Email, EmailRetype, Telemovel, Ano, Nivel,
					NumberOfVisits, SituacaoInscricao, ReferenciaConfirmacao, data_inscricao, data_confirmacao, data_cancelamento, Data) 
					VALUES (:NomeCompleto, :Curso, :Escola, :Email, :EmailRetype, :Telemovel, :Ano, :Nivel, :NumberOfVisits, :SituacaoInscricao, :ReferenciaConfirmacao, :data_inscricao, :data_confirmacao, :data_cancelamento, :Data)";
        $stmt = $ligacao->prepare($sql);
        $stmt->bindParam(':NomeCompleto',$nomeCompleto);
        $stmt->bindParam(':Curso',$curso);
        $stmt->bindParam(':Escola',$escola);
        $stmt->bindParam(':Email',$email);
        $stmt->bindParam(':EmailRetype',$emailRetype);
        $stmt->bindParam(':Telemovel',$telemovel);
        $stmt->bindParam(':Ano',$ano);
        $stmt->bindParam(':Nivel',$nivel);
        $stmt->bindParam(':NumberOfVisits',$numberOfVisits);
        $stmt->bindParam(':SituacaoInscricao',$situacaoInscricao);
        $stmt->bindParam(':ReferenciaConfirmacao',$referenciaConfirmacao);
        $stmt->bindParam(':data_inscricao',$data_inscricao);
        $stmt->bindParam(':data_confirmacao',$data_confirmacao);
        $stmt->bindParam(':data_cancelamento',$data_cancelamento);
        $stmt->bindParam(':Data',$data);
        $res = $stmt->execute();
    } catch (PDOException $pe) {
        //die($pe->getMessage());
				$res = false;
    }
    if ($res == false) {
        $V[] = "<p>Não foi possível registar a sua inscrição.</p>";
        $ERR++;
    }

    if ($ERR) {
        echo "<h1>A inscrição não foi efetuada.</h1>";
        echo "<h2>Apresenta as seguintes incorreções.</h2>";
        echo "<ul>";
        for ($i = 0; $i < count($V); $i++)
            echo "<li>$V[$i]</li>";
        echo "</ul>";
        echo "<h2>Por favor, preencha os dados corretamente e tente de novo.</h2>";
        echo $msg_voltar;
    }

    //$obj_part->listAllHTML();
    if ($situacaoInscricao == 'CONFIRMADA')
        $cor = "style=background-color:#5CE638;";
    else
        $cor = "style=background-color:#ec971f;";

    $sd = <<<_END
            <h1>Inscrição Registada com Sucesso</h1><table style=';margin-left: 2em'>
    <tr><td>Nome completo</td><td> $nomeCompleto</td></tr>
    <tr><td>Escola</td><td> $escola</td></tr>
    <tr><td>Ano</td><td>$ano</td></tr>
    <tr><td>Curso</td><td> $curso</td></tr>
    <tr><td>Email</td><td> $email</td></tr>
    <tr><td>EmailRetype</td><td> $emailRetype</td></tr>
    <tr><td>Telemóvel</td><td> $telemovel</td></tr>
    <tr><td>Situação inscrição</td><td $cor> $situacaoInscricao</td></tr>
    <tr><td>Data</td><td> $data</td></tr></table>
_END;
    echo $sd;

    unset($_SESSION['nomeCompleto']);
    unset($_SESSION['ano']);
    unset($_SESSION['escola']) ;
    unset($_SESSION['curso']);
    unset($_SESSION['email']) ;
    unset($_SESSION['emailRetype']);
    unset($_SESSION['telemovel']);
    $_SESSION = array();
    session_destroy();

    echo "<p  style='margin-left: 2em'><a href='Participants_lista.php'><input type='button' class='btn' value='Voltar à página principal' /></a></p>";						
?>
</div>
		<div id='rodape'>	
			<?php include('rodape.php'); ?>
		</div>		
	</div>	
</html>
