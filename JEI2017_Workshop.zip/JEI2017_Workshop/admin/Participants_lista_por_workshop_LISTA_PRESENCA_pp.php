﻿<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
require_once 'CBaseFormValidation.php';

$_JEI = 'JEI2016';
$LINK_HOME = "http://www.jei.ipg.pt/$_JEI/index.php";
$LINK_ATRAS = htmlspecialchars("Participants.php");
$msg_voltar = "<p>Clique no botão retroceder do seu browser para voltar ao formulário.</p>";
$msg_voltar = "<br /><a style='color:#45aed6; font-size:14px;' href='$LINK_HOME'>JEI'16</a>";

$op =0;
if (isset($_REQUEST['SITUACAO'])) {
	$situacao = CBaseFormValidation::test_input($_REQUEST['SITUACAO']) ;
	if (($situacao == 'INSCRITOS') || ($situacao == 'INSCRITOS') || ($situacao == 'INSCRITOS')) {
		$op = 1;
	}
}
if ($op == 0)
{
	echo $msg_voltar;
	return;
}
$reg = intval(CBaseFormValidation::test_input($_REQUEST['r'])) ;
// http://www.jei.ipg.pt/JEI2016/AccessRegisterList.php?SITUACAO=INSCRITOS
//http://www.jei.ipg.pt/JEI2016/AccessRegisterList.php?SITUACAO=INSCRITOS&r=1
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="pt">
  <title>Ficha de Inscrição: Participantes: Lista</title>
  <link rel='stylesheet' type='text/css' href='estilos.css'>
  <link rel='stylesheet' type='text/css' href='estilos_lista.css'>
  <style type='text/css'>
  table.lista {border-collapse: collapse;border: solid 1px black;background-color: white;}
  
  
  th.lista{border: solid 1px black;text-align:center;color:black;padding: 4px;}
  td.lista{border: solid 1px black;text-align: left;padding: 4px; color: black;}
  td.lista_true{border: solid 1px blue;text-align: left;padding: 4px;color: black; background-color:#77FF00;}
  
  th{border: solid 1px blue;text-align:left;color:black;padding: 4px;}
  td{border: solid 1px blue;text-align: left;padding: 4px;color: #8b4513;}
  div {margin-bottom: 10px; width: 70%; padding: 10px; border: solid thin black;}

  img.button {border: 1px solid #999999;  margin: 3px; padding: 1px;}
  a:hover img.button {border: 1px dashed #555555;	margin: 3px; padding: 1px;}
  a:hover img {border: 1px dashed #555555;	margin: 3px; padding: 1px;}
  //img { border: 1px solid #999999;  margin: 3px; padding: 1px;}
  
  
  h1 {color: black; font-size:18pt;}
  h2 {color: black; font-size:14pt;}
  
  </style>
</head>
<body>
  
  <?php
  // echo "<h2>Lista</h2>";
    include('../DataBase/data_base_open.php');
	include('../UserAccounts/User_Logged.php');
    include('../UserAccounts/Administrator.php');
   
   
    if (isset($_REQUEST['SituacaoInscricao'])) {
	$SituacaoInscricao = $_REQUEST['SituacaoInscricao'];
	if ($SituacaoInscricao != 'TODOS') {
		$wh = " SituacaoInscricao = '$SituacaoInscricao' and "; 
	
	}
  }
  
  
   $Periodo = $_REQUEST['Periodo'];
   $ws = $_REQUEST['IDWS'];
   
	if ($Periodo == 'Manha')
		$i=0;
	else 
		$i=1;	
   
    $RR[] = 'Manha';$RR2[] = 'Manhã';
    $RR[] = 'Tarde';$RR2[] = 'Tarde';
	$total = 0;
  
	
	$sql3 = "SELECT * FROM Workshops where ID='" .$ws. "'";
	 //echo $sql3;
	$result3 = mysql_query($sql3, $connection);
	if(!$result3) die("Erro, leitura não efectuada: " . mysql_error());
	$row3 = mysql_fetch_array($result3);
	$Workshop  = $row3['Workshop'];
	$Username1 = $row3['Username1'];
	$Username2 = $row3['Username2'];
	
	//echo $Workshop ;
	
	 		$Oradores = "$Username1";
		$sql = "SELECT * FROM UserAccounts where Username = '$Username1'";
		$result2 = mysql_query($sql, $connection);
   	$Nome1 = "";
		$Email1 = "";
		if (mysql_num_rows($result2)) {
			$row2 = mysql_fetch_array($result2);
			$Nome1 = $row2['Nome'];
			$Email1 = $row2['Email'];
			$Oradores = $Nome1;
		}
		
		
		$sql = "SELECT * FROM UserAccounts where Username = '$Username2'";
		$result2 = mysql_query($sql, $connection);
   	$Nome2 = "";
		$Email2 = "";
		if (mysql_num_rows($result2)) {
			$row2 = mysql_fetch_array($result2);
			$Nome2 = $row2['Nome'];
			$Email2 = $row2['Email'];
			$Oradores .= " e " . $Nome2;
		} 
	
	 
	if ($Workshop == "")
	 if ($i==0)
	  $Workshop = "Participantes que não escolheram nenhum workshop de manhã.";
	else
	  $Workshop = "Participantes que não escolheram nenhum workshop de tarde.";

	  
	  
	echo "<p><img src='../images/logo500.png' width='40%' height='40%' /></p>";
	
	echo "<h1>$Workshop  - SituacaoInscricao = $SituacaoInscricao</h1>";
	echo "<h2>Oradores: $Oradores <span style='font-size:10pt;'>(Duração: 2 Horas)</span></h2>";		
	
	echo "<h2>Lista de presenças: <A HREF='javascript:window.print()'>$RR2[$i]</A></h2>";		
	

	
	$sql = "SELECT * FROM Participants where $wh $RR[$i]='" .$ws. "'" . " order by NomeCompleto";
//echo $sql;
	$result = mysql_query($sql, $connection);
	$N = mysql_num_rows($result);
  
	//echo "<p>"."Total de inscritos: ".$N."</p>";
	echo "<table class='lista'><tr>";
		
	
	echo "<th class='lista'>Nº</th>";
	echo "<th class='lista'>ID</th>";
	echo "<th class='lista'>Número</th>";
	echo "<th class='lista'>NomeCompleto</th>";
	echo "<th class='lista'>Assinatura</th>";
  
	echo '</tr>';
	$NN = 0;
	while($row = mysql_fetch_array($result)) {
	  $total ++;
	  $NN++;
      echo '<tr>';
      $ID  = $row['ID'];
	  $CdAluno = $row['CdAluno'];
	  echo "<td class='lista'>$NN</td>";
	  echo "<td class='lista'>$ID</td>";
	  
      $NomeCompleto = $row['NomeCompleto']; 
	  echo "<td class='lista'>$CdAluno</td>";
      echo "<td class='lista'>$NomeCompleto</td>";
	      
	  
	  $sss =  str_repeat("&nbsp;", 70);
      echo "<td class='lista'>$sss</td>";
	
	  $x = "$RR[$i]";
      $Manha = $row[$x];
      echo '</tr>';
    }
    for ($j=$N+1; $j<=22; $j++)  {
	  echo "<tr><td class='lista'>$j</td><td class='lista'>&nbsp;</td><td class='lista'>&nbsp;</td><td class='lista'>&nbsp;</td><td class='lista'>&nbsp;</td></tr>";
    }
  echo '</table>';

  include('../DataBase/data_base_close.php');
  ?>
</body>
</html>
