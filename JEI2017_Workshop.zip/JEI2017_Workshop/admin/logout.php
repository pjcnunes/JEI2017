<?php
/**
 * User: pnunes
 * Date: 28-03-2016
 * Time: 02:23
 */
session_start();

if (isset($_SESSION['Nome']) && isset($_SESSION['Nivel'])) {
    unset($_SESSION['Nome']);                //Destroi variáveis de sessão e sessão
    unset($_SESSION['Nivel']);                //Destroi variáveis de sessão e sessão
    $_SESSION = array();
    session_destroy();
    //header("HTTP/1.1 301 Moved Permanently");
    header("Refresh: 1; url=login.php");
    echo '<p>Logout efetuado com sucesso.</p>';
    echo '<p>Redirect in 1 sec.</p>';
}
