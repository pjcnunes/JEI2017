<?php
/**
  * User: pnunes
 * Date: 28-03-2016
 * Time: 02:37
 */

//session_start();
if (isset($_SESSION['Nome']) && isset($_SESSION['Nivel'])) {
    $Nome = $_SESSION['Nome'];
    $Nivel = $_SESSION['Nivel'];
		if (intval($Nivel) < 1) {
			echo 'Acesso interdito: admin<br>';
			header("Location: login.php");
			echo '<p>Redirect in 3 sec.</p>';
		}
} else {
    echo 'Acesso interdito <br>';
    header("Location: login.php");
    echo '<p>Redirect in 3 sec.</p>';
}