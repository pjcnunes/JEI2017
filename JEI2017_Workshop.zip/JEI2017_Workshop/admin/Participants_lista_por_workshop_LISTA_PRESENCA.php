﻿<?php
session_start();
header('Content-Type: text/html; charset=utf-8');
require_once 'CBaseFormValidation.php';

$_JEI = 'JEI2016';
$LINK_HOME = "http://www.jei.ipg.pt/$_JEI/index.php";
$LINK_ATRAS = htmlspecialchars("Participants.php");
$msg_voltar = "<p>Clique no botão retroceder do seu browser para voltar ao formulário.</p>";
$msg_voltar = "<br /><a style='color:#45aed6; font-size:14px;' href='$LINK_HOME'>JEI'16</a>";

$op =0;
if (isset($_REQUEST['SITUACAO'])) {
    $situacao = CBaseFormValidation::test_input($_REQUEST['SITUACAO']) ;
    if (($situacao == 'INSCRITOS') || ($situacao == 'INSCRITOS') || ($situacao == 'INSCRITOS')) {
        $op = 1;
    }
}
if ($op == 0)
{
    echo $msg_voltar;
    return;
}
$reg = intval(CBaseFormValidation::test_input($_REQUEST['r'])) ;
// http://www.jei.ipg.pt/JEI2016/Participants_lista_por_workshop_LISTA_PRESENCA.php.?SITUACAO=INSCRITOS
//http://www.jei.ipg.pt/JEI2016/Participants_lista_por_workshop_LISTA_PRESENCA.php?SITUACAO=INSCRITOS&r=1
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="pt">
  <title>Ficha de Inscrição: Participantes: Lista</title>
  <link rel='stylesheet' type='text/css' href='estilos.css'>
  <link rel='stylesheet' type='text/css' href='estilos_lista.css'>
  <style type='text/css'>
  table.lista {border-collapse: collapse;border: solid 1px blue;background-color: #f0e68c;}
  th.lista{border: solid 1px blue;text-align:center;color:blue;padding: 4px;}
  td.lista{border: solid 1px blue;text-align: left;padding: 4px;color: #8b4513;}
  td.lista_true{border: solid 1px blue;text-align: left;padding: 4px;color: #8b4513; background-color:#77FF00;}
  th{border: solid 1px blue;text-align:left;color:blue;padding: 4px;}
  td{border: solid 1px blue;text-align: left;padding: 4px;color: #8b4513;}
  div {margin-bottom: 10px; width: 70%; padding: 10px; border: solid thin black;}

  img.button {border: 1px solid #999999;  margin: 3px; padding: 1px;}
  a:hover img.button {border: 1px dashed #555555;	margin: 3px; padding: 1px;}
  a:hover img {border: 1px dashed #555555;	margin: 3px; padding: 1px;}
  img { border: 1px solid #999999;  margin: 3px; padding: 1px;}
  </style>
</head>
<body>
  <h1>Participantes: Folhas de presenças</h1>
  <?php
  // echo "<h2>Lista</h2>";
   include('../DataBase/data_base_open.php');
   
    // include('../UserAccounts/User_Logged.php');
  //include('../UserAccounts/Administrator.php');
   
   $RR[] = 'Manha';$RR2[] = 'Manhã';
    $RR[] = 'Tarde';$RR2[] = 'Tarde';
	$total = 0;
	
	
	$wh = ''; $wh2 = '';
  if (isset($_REQUEST['SituacaoInscricao'])) {
	$SituacaoInscricao = $_REQUEST['SituacaoInscricao'];
	if ($SituacaoInscricao != 'TODOS') {
		$wh = "where SituacaoInscricao = '$SituacaoInscricao'"; 
		$wh2 = " and (SituacaoInscricao = '$SituacaoInscricao')"; 
	}
  }
	
	 $s = "SituacaoInscricao=TODOS";
	$Prog = "Participants_lista_por_workshop_LISTA_PRESENCA";
	 
  echo "<p><a href='$Prog.php?$s'>TODAS</a></p>";
    
  $s = "SituacaoInscricao=NAO CONFIRMADA";
  echo "<p><a href='$Prog.php?$s'>NAO CONFIRMADAS</a></p>";	
	
  $s = "SituacaoInscricao=CONFIRMADA";
  echo "<p><a href='$Prog.php?$s'>CONFIRMADAS</a></p>";	
	
  $s = "SituacaoInscricao=CANCELADA";
  echo "<p><a href='$Prog.php?$s'>CANCELADAS</a></p>";
  
  
	
	
for($i=0; $i<2; $i++) {
   $sql2 = "SELECT $RR[$i] WS, count($RR[$i]) N FROM Participants $wh group by $RR[$i]";
   $result2 = mysql_query($sql2, $connection);
   $N2 = mysql_num_rows($result2);
   //if(!$result2) die("Erro, registo não efectuado: " . mysql_error());
   //echo $sql2;

  
  echo "<h1>Workshops: $RR2[$i] - SituacaoInscricao = $SituacaoInscricao</h1>"; 
  
  echo "<table class='lista'><tr>";
  echo "<th class='lista'>Workshop</th>";
  echo "<th class='lista'>Nº</th>";
  echo "</tr>";
  
  
  while($row2 = mysql_fetch_array($result2)) {
  
	$ws  = $row2['WS'];
	$sql3 = "SELECT ID, Workshop FROM Workshops where ID='" .$ws. "'";
	 //echo $sql3;
	$result3 = mysql_query($sql3, $connection);
	if(!$result3) die("Erro, registo não efectuado: " . mysql_error());
	$row3 = mysql_fetch_array($result3);
	$Workshop  = $row3['Workshop'];
	$ID = $ws;

	 
	if ($Workshop == "")
	 if ($i==0)
	  $Workshop = "Participantes que não escolheram nenhum workshop de manhã.";
	else
	  $Workshop = "Participantes que não escolheram nenhum workshop de tarde.";

	
	$sql = "SELECT * FROM Participants where $RR[$i]='" .$ws. "'" . $wh2;
	//echo $sql;
	$result = mysql_query($sql, $connection);
	$N = mysql_num_rows($result);
	
	echo "<tr>";
    echo "<td class='lista'><a href='Participants_lista_por_workshop_LISTA_PRESENCA_pp.php?SituacaoInscricao=$SituacaoInscricao&Periodo=$RR[$i]&IDWS=$ID'>$Workshop</a></td>";
	echo "<td class='lista'>$N</td>";
	echo "</tr>";
   } 
 echo '</table>';
}

  include('../DataBase/data_base_close.php');
  ?>
</body>
</html>
